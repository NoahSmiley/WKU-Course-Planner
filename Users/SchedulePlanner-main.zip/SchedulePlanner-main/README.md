# SchedulePlanner
WKU Interactive SEAS( School of Engineering and Applied Sciences) Schedule Planner
