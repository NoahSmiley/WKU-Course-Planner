from django.apps import AppConfig


class SeasCoursePlannerConfig(AppConfig):
    name = 'SEAS_Course_Planner'
